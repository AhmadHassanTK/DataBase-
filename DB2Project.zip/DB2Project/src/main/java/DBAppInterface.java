import java.io.IOException;
import java.text.ParseException;
import java.util.Hashtable;
import java.util.Iterator;

public interface DBAppInterface {

    void init()throws DBAppException;

    void createTable(String tableName, String clusteringKey, Hashtable<String,String> colNameType, Hashtable<String,String> colNameMin, Hashtable<String,String> colNameMax) throws DBAppException , IOException, ParseException,ClassNotFoundException;

    void createIndex(String tableName, String[] columnNames) throws DBAppException,ClassNotFoundException, IOException,ParseException;

    void insertIntoTable(String tableName, Hashtable<String, Object> colNameValue) throws DBAppException, IOException,ParseException,ClassNotFoundException;

    void updateTable(String tableName, String clusteringKeyValue, Hashtable<String, Object> columnNameValue) throws DBAppException, NumberFormatException, IOException, ParseException ,ClassNotFoundException;

    void deleteFromTable(String tableName, Hashtable<String, Object> columnNameValue) throws DBAppException,IOException, ParseException,ClassNotFoundException;

    Iterator selectFromTable(SQLTerm[] sqlTerms, String[] arrayOperators) throws DBAppException,ClassNotFoundException, IOException,ParseException ;


}
