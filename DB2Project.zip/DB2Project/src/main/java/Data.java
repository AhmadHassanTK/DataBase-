import java.io.Serializable;
import java.util.Vector;

public class Data implements Serializable {
	public  Object maxValue ;
	public  Object minValue ;
	public  String path ;
	
	boolean OverFlow =false;
	public Vector<Data> Flow =new Vector<Data>();
	
	public int NumberOfRows=0;
	
	public Data() {
		
		
	}
}
