import java.io.Serializable;
import java.util.Vector;


public class Tabels extends Vector<Tabel> implements Serializable {


	public Tabels () {
		
	}
}
