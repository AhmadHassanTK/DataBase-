import java.io.Serializable;
import java.util.Vector;

public class Gridindex extends Vector implements Serializable  {
	

	public Vector<Vector<Range>> indexColRange=new Vector() ;
	public String table;
	public  Vector indexcol=new Vector(); 
	public int number=0;
}
