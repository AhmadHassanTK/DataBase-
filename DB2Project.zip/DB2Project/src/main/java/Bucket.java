import java.io.Serializable;
import java.util.TreeMap;
import java.util.Vector;

public class Bucket extends TreeMap<String,Vector>implements Serializable{

	public Vector<String> Overflow =new Vector();;
	
}
