import java.io.Serializable;
import java.util.Vector;

public class Tabel implements Serializable {
public int number=0;
public String name ;
public String key;
public Vector<Data> pages =new Vector<Data>();
public Vector clusteringKeys =new Vector(); 

public int Gridnumber =0;
public Vector<String> Gridindex = new Vector(); 

public Tabel () {
	
}

}
