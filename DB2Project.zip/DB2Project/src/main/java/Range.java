import java.io.Serializable;

public class Range implements Serializable {
	public String col;
	public Object max;
	public Object min;
}
