import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

public class DBApp implements DBAppInterface{

	public static int maxRow;
	
	public void init() {
		String cofig ="MaximumRowsCountinPage";
		maxRow=getPropValues(cofig);
		if(!(new File("src/main/resources/data").exists())) {
			File file =new File("src/main/resources/data");
			file.mkdirs();
			}
		
	}

	public void createTable(String tableName, String clusteringKey, Hashtable<String, String> colNameType,
			Hashtable<String, String> colNameMin, Hashtable<String, String> colNameMax) throws DBAppException, IOException, ParseException, ClassNotFoundException {
		
		if(!(new File("src/main/resources/data/Tabels.class").exists())) {
			Tabels tables=new Tabels();
			Write("src/main/resources/data/Tabels.class",tables);
			}
		
		Tabels tab=(Tabels) Read("src/main/resources/data/Tabels.class");
	
		for(int i =0 ; i< tab.size();i++) {
			 if(tab.get(i).name.equals(tableName)) {
				 throw new DBAppException("Table already exist");
			 }}
		
		Enumeration names1;
		String key1;
		names1 = colNameType.keys();
		while(names1.hasMoreElements()) {
			key1 = (String) names1.nextElement();
			if((colNameType.get(key1)).equals("java.lang.Integer")||(colNameType.get(key1)).equals("java.lang.String")||(colNameType.get(key1)).equals("java.lang.Double")||(colNameType.get(key1)).equals("java.util.Date")) {
			if((colNameType.get(key1)).equals("java.util.Date")) {
				try {Date test =new SimpleDateFormat("yyyy-MM-dd").parse(colNameMin.get(key1).toString());
					Date test1 =new SimpleDateFormat("yyyy-MM-dd").parse(colNameMax.get(key1).toString());
				}
				catch(ParseException e) {throw new DBAppException("data format not supported");}
			}
			}else {
				
				throw new DBAppException("Unsupported data type"); }
			}
		
		
		Tabel tabel  = new Tabel();
		tabel.name=tableName;
		tabel.key=clusteringKey;
		
		FileWriter fw = new FileWriter("src/main/resources/metadata.csv",true);
		BufferedWriter bw =new BufferedWriter(fw);
		PrintWriter pw = new PrintWriter(bw);
		
		Enumeration names;
		String key;
		names = colNameType.keys();
		while(names.hasMoreElements()) {
			key = (String) names.nextElement();
				boolean ClusteringKey=false;
			if(key==clusteringKey) {
				ClusteringKey=true;
			}
	      pw.println(tableName+","+key+","+ colNameType.get(key)+","+ClusteringKey+","+"false"+","+colNameMin.get(key)+","+colNameMax.get(key));
			}
			
		pw.flush();
		pw.close();
		
		File file =new File("src/main/resources/data/"+tableName);
		file.mkdirs();
		
		tab.add(tabel);
		
		
	Write("src/main/resources/data/Tabels.class",tab);
	
	}
	
	public void createIndex(String tableName, String[] columnNames) throws DBAppException, ClassNotFoundException, IOException, ParseException {
	
		Tabels tab=(Tabels) Read("src/main/resources/data/Tabels.class");
		if( tab.size()==0) {throw new DBAppException("Table does not exist");}
		int index=0;
		boolean found1=false;
		for(int i =0 ; i< tab.size();i++) {
		 if(tab.get(i).name.equals(tableName)) {
			  index=i;
			  found1=true;
			  break;
		 }
	 }if(!found1){throw new DBAppException("Table does not exist");}
	 
	 for(int i=0;i<columnNames.length;i++) {
		 checkCol(tableName,columnNames[i]);
		 
		 String row;
		 BufferedReader csvReader = new BufferedReader(new FileReader("src/main/resources/metadata.csv"));
		 while ((row = csvReader.readLine()) != null) {
		     String[] data = row.split(",");
		if(data[0].equals(tableName) && data[1].equals(columnNames[i]) ) {
			data[4]="true";
		}
		 }
		 csvReader.close();
		 
	 }
	 
		 Gridindex g=new Gridindex();
		 for(int i=0;i<columnNames.length;i++) {
			g.indexcol.add(columnNames[i]);
		 }
		 
		 
		 if(columnNames.length==1) {
			 g.setSize(10);
			 g.table=tableName;
			 }
		 else if(columnNames.length==2) {
			 g.table=tableName;
				for(int k=0;k<10;k++) {	
				Vector y=new Vector();
				y.setSize(10);
			     g.add(y);
				 }
		 }
		 else if(columnNames.length==3) {
			 g.table=tableName;
				for(int k=0;k<10;k++) {	 
					 Vector x =new Vector();
				//	 x.setSize(10);
					 for(int k1=0;k1<10;k1++) {
						 Vector y=new Vector();
						 y.setSize(10);
						 x.add(y);
					 }
			    g.add(x);
				}
		 }
		 else {
			 g.table=tableName;
		for(int k=0;k<10;k++) {	 
			 Vector x =new Vector();
		//	 x.setSize(10);
			 Vector z=new Vector();
	//		 z.setSize(10);
			 x.add(z);
	    for(int j=2;j<columnNames.length-1;j++) {
	    	 Vector y= x;
		 for(int i=1;i<j;i++) {
			  y=(Vector)y.get(0);
		 } 
		 for(int k1=0;k1<10;k1++) {
			 Vector v=new Vector();
			 v.setSize(10);
			 y.add(v);
		 }
		 }
	    g.add(x);
		 }
		
	 }
		 
		 for(int i=0;i<columnNames.length;i++) {
			 Vector GridRange =new Vector();
			 switch (
						(getType(tableName,columnNames[i]))
					) {
					case "java.lang.Integer":
						if(true) {
						String x=getMin(tableName,columnNames[i]);
						int y=Integer.parseInt(x);
						
						String x1=getMax(tableName,columnNames[i]);
						int y1=Integer.parseInt(x1);
						
						int range =(y1-y);
						range =range/10;
						int u=y;
						  
						for(int k=0;k<10;k++) {
							 Range r =new Range ();
							 r.col=columnNames[i];
							 
							r.min=u;
							r.max=u+range;
							
							GridRange.add(r);
							u+=range;
						}
						g.indexColRange.add(GridRange);
						}
						break;
					case "java.lang.String":
						if(true) {
							if(Character.isDigit(getMin(tableName,columnNames[i]).charAt(0))){
								String x=getMin(tableName,columnNames[i]);
								int y=x.charAt(0);
								Double z=(double)y;
								
								String x1=getMax(tableName,columnNames[i]);
								int y1=x1.charAt(0);
								Double z1=(double)y1;
								
								Double range =(z1-z) ;
								range =range /10;
								Double u=z; 
							    
							    for(int k=0;k<10;k++) {
							    	 Range r =new Range ();
									 r.col=columnNames[i];
									
									 Double min=u;
									    Double max=u+range;
									    int IntValue = (int) Math.round(min);
									    int IntValue1 = (int) Math.round(max);
								
									    String finalmin=(char)IntValue+""+x.substring(1);
									    String finalmax=(char)IntValue1+""+x1.substring(1);
									    if(k==9) {finalmax=x1;}
									   
										r.min=(finalmin);
										r.max=(finalmax);
										GridRange.add(r);
										u+=range;
							    }
							    g.indexColRange.add(GridRange);
							}else {
								String x=getMin(tableName,columnNames[i]);
								int y=x.charAt(0);
								Double z=(double)y;
								
								String x1=getMax(tableName,columnNames[i]);
								int y1=x1.charAt(0);
								Double z1=(double)y1;
								
								Double range =(z1-z) ;
								range =range /10;
								Double u=z; 
							    
							    for(int k=0;k<10;k++) {
							    	 Range r =new Range ();
									 r.col=columnNames[i];
									
									 Double min=u;
									    Double max=u+range;
									    int IntValue = (int) Math.round(min);
									    int IntValue1 = (int) Math.round(max);
									    if(IntValue>90 &&IntValue<97) {IntValue=97;}
									    if(IntValue1>90 &&IntValue1<97) {IntValue1=97;}
									    
									    String finalmin=(char)IntValue+"";
									    String finalmax=(char)IntValue1+"";
									    for(int l=0;l<x1.length()-1;l++) {finalmin+="A";}
									    for(int l=0;l<x1.length()-1;l++) {finalmax+="z";}
									    if(k==9) {finalmax=x1;}
									   
										r.min=(finalmin);
										r.max=(finalmax);
										GridRange.add(r);
										u+=range;
							    }
							    g.indexColRange.add(GridRange);
							}
						}
						break;
					case "java.lang.Double":
						if(true) {
						String x=getMin(tableName,columnNames[i]);
						double y=Double.parseDouble(x);
						
						String x1=getMax(tableName,columnNames[i]);
						double y1=Double.parseDouble(x1);
						
						double range =(y1-y);
						range =range/10 ;
						double u=y;
						  
						for(int k=0;k<10;k++) {
							 Range r =new Range ();
							 r.col=columnNames[i];
							 
							r.min=u;
							r.max=u+range;
							
							GridRange.add(r);
							
							u+=range;
						}
						g.indexColRange.add(GridRange);
						}
						break;
					case "java.util.Date":
						if(true) {
							String min=getMin(tableName,columnNames[i]);
							String max =getMax(tableName,columnNames[i]);
							
							String x=min.substring(0, 4);
							int y =Integer.parseInt(x);
							
							String x1=max.substring(0, 4);
							int y1 =Integer.parseInt(x1);
							
							int range =(y1-y) ;
							range =range /10;
							int u=y; 
						    						    
						    for(int k=0;k<10;k++) {
						    	 Range r =new Range ();
								 r.col=columnNames[i];
								
								String finalmin=u+min.substring(4);
								Date datemin=(new SimpleDateFormat("yyyy-MM-dd").parse(finalmin));
								r.min=datemin;
								
								int maxx=u+range;
								String finalmax=maxx+max.substring(4);
								Date datemax=(new SimpleDateFormat("yyyy-MM-dd").parse(finalmax));
								r.max=datemax;
								GridRange.add(r);
								u=u+range;
							}  
						    g.indexColRange.add(GridRange);
						}
						break;
					}
		 } 
		 int nn= tab.get(index).Gridnumber;
		 Write("src/main/resources/data/"+tableName+"/"+"Gridindex"+nn+".class",g);
		 tab.get(index).Gridnumber++;
		 tab.get(index).Gridindex.add("src/main/resources/data/"+tableName+"/"+"Gridindex"+ tab.get(index).Gridnumber+".class");
		 Write("src/main/resources/data/Tabels.class",tab);
		
		 if(tab.get(index).pages.size()!=0) {
			 for(int i =0 ;i<tab.get(index).pages.size();i++) {
				 Page x=(Page)Read(tab.get(index).pages.get(i).path);
				 for(int j=0;j<x.size();j++) {
					 Vector insert =new Vector();
					 insert.setSize(g.indexcol.size());
					 Hashtable y=(Hashtable)x.get(j);
					
					 Enumeration names;
					 String key;
					 names = y.keys();
					 int count=0;
					 while(names.hasMoreElements()) {
							key = (String) names.nextElement();
							if(g.indexcol.contains(key)) {
								count++;
								int place =g.indexcol.indexOf(key);
								for(int k=0;k<10;k++) {
									switch (
											(getType(tableName,key))
										) {
										case "java.lang.Integer":
											if(k==9) {if((int)g.indexColRange.get(place).get(k).max>=(int)y.get(key) && (int)g.indexColRange.get(place).get(k).min<=(int)y.get(key)) {
												insert.setElementAt(k, place);
											}}else {
											if((int)g.indexColRange.get(place).get(k).max>(int)y.get(key) && (int)g.indexColRange.get(place).get(k).min<=(int)y.get(key)) {
												insert.setElementAt(k, place);
											}}
											break;
										case "java.lang.String":
											String a=(String)g.indexColRange.get(place).get(k).max;
											String b=(String)g.indexColRange.get(place).get(k).min;
											if(k==9) {if(a.compareTo((String)y.get(key))>=0 && b.compareTo((String)y.get(key))<=0) {
												insert.setElementAt(k, place);
											}}else {
											if(a.compareTo((String)y.get(key))>0 && b.compareTo((String)y.get(key))<=0) {
												insert.setElementAt(k, place);
											}}
											break;
										case "java.lang.Double":
											if(k==9) {if((double)g.indexColRange.get(place).get(k).max>=(double)y.get(key) && (double)g.indexColRange.get(place).get(k).min<=(double)y.get(key)) {
												insert.setElementAt(k, place);
											}}else {
											if((double)g.indexColRange.get(place).get(k).max>(double)y.get(key) && (double)g.indexColRange.get(place).get(k).min<=(double)y.get(key)) {
												insert.setElementAt(k, place);
											}}
											break;
										case "java.util.Date":
											Date aa=(Date)g.indexColRange.get(place).get(k).max;
											Date bb=(Date)g.indexColRange.get(place).get(k).min;
											if(k==9) {if(aa.compareTo((Date)y.get(key))>=0 && bb.compareTo((Date)y.get(key))<=0) {
												insert.setElementAt(k, place);
											}}else {
											if(aa.compareTo((Date)y.get(key))>0 && bb.compareTo((Date)y.get(key))<=0) {
												insert.setElementAt(k, place);
											}}
											break;
										}
								}
							}
					 }
					 
					 if(count==g.indexcol.size()) {
						 
						 Vector values=new Vector();
							for(int u=0;u<g.indexcol.size();u++) {
								values.add(y.get(g.indexcol.get(u)));
							}
						
							//		Vector tmp =new Vector();
									Vector	tmp=g;
								//	 System.out.println(insert.toString());
									for(int n=0;n<insert.size()-1;n++) {
										tmp=(Vector)tmp.get((int)insert.get(n));
									}
									
//									System.out.println(tmp.get(insert.size()-1).toString());
						
									if(tmp.get((int)insert.get(insert.size()-1))==null) {
										Bucket b=new Bucket();
										Vector list=new Vector();
										
										list.add(values);
										list.add(tab.get(index).pages.get(i).path);
										b.put(y.get(tab.get(index).key)+"",list); //////// key in bucket is in String fooooorm
										Write("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class",b);
										tmp.setElementAt("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class", (int)insert.get(insert.size()-1));
										g.number++;
									}
									else {
									Bucket bb=(Bucket)Read((String)tmp.get((int)insert.get(insert.size()-1)));
									if(bb.size()!=maxRow) {
										Vector list=new Vector();
										list.add(values);
										list.add(tab.get(index).pages.get(i).path);
									bb.put(y.get(tab.get(index).key)+"", list);
									Write((String)tmp.get((int)insert.get(insert.size()-1)),bb);
									}
									else if(bb.Overflow.size()==0){
										Bucket b=new Bucket();
										Vector list=new Vector();
										list.add(values);
										list.add(tab.get(index).pages.get(i).path);
										b.put(y.get(tab.get(index).key)+"", list); //////// key in bucket is in String fooooorm
										
										bb.Overflow.add("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class");
										Write((String)tmp.get((int)insert.get(insert.size()-1)),bb);
										
										Write("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class",b);
										g.number++;
									//	tmp.insertElementAt("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class", (int)insert.get(insert.size()-1));
									}else {
										Bucket last=(Bucket)Read((String)bb.Overflow.get(bb.Overflow.size()-1));
										if(last.size()!=maxRow) {
											Vector list=new Vector();
											list.add(values);
											list.add(tab.get(index).pages.get(i).path);
											last.put(y.get(tab.get(index).key)+"", list);
											Write((String)bb.Overflow.get(bb.Overflow.size()-1),last);
										}else {
											Bucket b=new Bucket();	
											Vector list=new Vector();
											list.add(values);
											list.add(tab.get(index).pages.get(i).path);
											b.put(y.get(tab.get(index).key)+"", list); //////// key in bucket is in String fooooorm
											
											bb.Overflow.add("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class");
											Write((String)tmp.get((int)insert.get(insert.size()-1)),bb);
											
											Write("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class",b);
											g.number++;
										}
									}
									}
				 }
				 }
			 }
//			 int size =tab.get(index).Gridindex.size()-1;
//			 tab.get(index).Gridindex.remove(size);
//			 tab.get(index).Gridindex.insertElementAt(g, size);
			 Write("src/main/resources/data/"+tableName+"/"+"Gridindex"+nn+".class",g);
			 Write("src/main/resources/data/Tabels.class",tab);
		 }
	}
	
	public void insertIntoTable(String tableName, Hashtable<String, Object> colNameValue) throws DBAppException, IOException, ParseException, ClassNotFoundException {
		
		Tabels tab=(Tabels) Read("src/main/resources/data/Tabels.class");
		
		if( tab.size()==0) {throw new DBAppException("Table does not exist");}
		int index=0;
		boolean found=false;
		for(int i =0 ; i< tab.size();i++) {
		 if(tab.get(i).name.equals(tableName)) {
			  index=i;
			  found=true;
			  break;
		 }
	 }if(!found){throw new DBAppException("Table does not exist");}
	 
	 	Vector colwithindex=new Vector();//////////////////////////////
	 
		boolean	Pkey=false;
		Enumeration names;
		String key;
		names = colNameValue.keys();
		while(names.hasMoreElements()) {
			key = (String) names.nextElement();
			///////////////////////////////////////////////////////
			if(checkindex(tableName,key)) {
				colwithindex.add(key);
			}
			//////////////////////////////////////////////////////
			checkCol(tableName,key);
			if(key.equals(tab.get(index).key)) {
				Pkey=true;
				if(tab.get(index).clusteringKeys.size()==0) {tab.get(index).clusteringKeys.add(colNameValue.get(key));}
				else if(tab.get(index).clusteringKeys.contains(colNameValue.get(key))) {throw new DBAppException("this clusteringKey already exist");}
				else {tab.get(index).clusteringKeys.add(colNameValue.get(key));}
				}
			
			if((colNameValue.get(key).getClass().toString()).equals("class"+" "+getType(tableName,key))){
				switch (
						(getType(tableName,key))
					) {
					case "java.lang.Integer":
					int	x1 = Integer.parseInt(getMin(tableName,key));
					int y1=(int)colNameValue.get(key);
					int z1=Integer.parseInt(getMax(tableName,key));
					if(!(x1<=y1 && z1>=y1)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.lang.String":
					String x2 = getMin(tableName,key);
					String y2=(String)colNameValue.get(key);
					String z2=getMax(tableName,key);
					if(!(x2.compareTo(y2)<=0 && z2.compareTo(y2)>=0)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.lang.Double":
					Double	x3 = Double.parseDouble(getMin(tableName,key));
					Double  y3=(Double)colNameValue.get(key);
					Double z3=Double.parseDouble(getMax(tableName,key));
					if(!(x3<=y3 && z3>=y3)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.util.Date":
					Date	x4 = new SimpleDateFormat("yyyy-MM-dd").parse(getMin(tableName,key));
					Date    y4=(Date)colNameValue.get(key); 
					Date 	z4=new SimpleDateFormat("yyyy-MM-dd").parse(getMax(tableName,key));
					if(!(x4.compareTo(y4)<=0 && z4.compareTo(y4)>=0)) {throw new DBAppException("Value is out of range");}
						break;
					}
			}else {throw new DBAppException("Unsupported data type");} 
		}if (!Pkey) {throw new DBAppException("No primary key");}
		////////////////////////////////////////////////////////////////////////////////////////
		
		boolean useindex=false;
		Vector myPath=new Vector();
		myPath.setSize(4);
		boolean updateindex =false;
		Vector myInsert=new Vector();
		Gridindex myGridindex =new Gridindex();
		int Gridindexlocation=0;
		if(colwithindex.size()!=0) {
			
			int count =0;
			int minmum=0;
			for(int i=0;i<tab.get(index).Gridindex.size();i++) {
				count =0;
				Gridindex tmp=(Gridindex)Read(tab.get(index).Gridindex.get(i));
				Vector xx=tmp.indexcol;
				if(xx.contains(tab.get(index).key)) {
					for(int j=0;j<xx.size();j++) {
						if(colNameValue.containsKey(xx.get(j))) {
							count++;
						}else {
							break;
						}
					}
					if(count > minmum) {
						minmum=count;
						myGridindex=tmp;
						Gridindexlocation=i;
					}
				}
			}
			if(count!=0) {
				myPath=FindIndex(tab.get(index),colNameValue,myGridindex,count);
				if(myPath.get(0)!=null) {useindex=true;}
				myInsert=(Vector)myPath.get(2);
				if(myInsert!=null) {
					updateindex=true;
				}
			}

			
		}
		////////////////////////////////////////////////////////////////////////////////////////
		if(tab.get(index).pages.size()==0) {
			Data data = new Data();
			data.path="src/main/resources/data/"+tableName+"/"+tableName+tab.get(index).number+".class";
			data.minValue=colNameValue.get(tab.get(index).key);
			data.maxValue=colNameValue.get(tab.get(index).key);
			data.NumberOfRows++;
			
			Page page = new Page();
			page.add(colNameValue);
		
			Write("src/main/resources/data/"+tableName+"/"+tableName+tab.get(index).number+".class",page);
			tab.get(index).number++;
			
			tab.get(index).pages.add(data);
			
			Write("src/main/resources/data/Tabels.class",tab);

		}
		else { //////// Binary Search ////////////////////////
			String path=null;
			////////////////////////////////////////////////////////////////////////////////////////
			int dataindex=0;
			Vector search=new Vector();
			if(useindex) {
				int minindex;
				int maxindex;
				boolean add=false;
				for(int i=0 ;i<tab.get(index).pages.size();i++) {
					if(tab.get(index).pages.get(i).path.equals(myPath.get(0))) {minindex=i; add=true;}
					if(tab.get(index).pages.get(i).path.equals(myPath.get(1))) {maxindex=i; search.add(tab.get(index).pages.get(i).path);add=false; }
				if(add) {search.add(tab.get(index).pages.get(i).path);}
				}
				Object shearchKey=colNameValue.get((tab.get(index).key));
				 dataindex =binarySearch(search,shearchKey,tab.get(index));
				 path=tab.get(index).pages.get(dataindex).path;
				 
				 if(updateindex) {
					 
					 Vector values=new Vector();
						for(int u=0;u<myGridindex.indexcol.size();u++) {
							values.add(colNameValue.get(myGridindex.indexcol.get(u)));
						}
					 
						Vector	tmp=myGridindex;
						for(int n=0;n<myInsert.size()-1;n++) {
							tmp=(Vector)tmp.get((int)myInsert.get(n));
						}
						
						if(tmp.get((int)myInsert.get(myInsert.size()-1))==null) {
							Bucket b=new Bucket();
							Vector list=new Vector();
							list.add(values);
							list.add(path);
							b.put(colNameValue.get(tab.get(index).key)+"",list); //////// key in bucket is in String fooooorm
							Write("src/main/resources/data/"+tableName+"/"+"Bucket"+myGridindex.number+".class",b);
							
							tmp.setElementAt("src/main/resources/data/"+tableName+"/"+"Bucket"+myGridindex.number+".class", (int)myInsert.get(myInsert.size()-1));
							myGridindex.number++;
						}
						else {
						Bucket bb=(Bucket)Read((String)tmp.get((int)myInsert.get(myInsert.size()-1)));
						if(bb.size()!=maxRow) {
							Vector list=new Vector();
							list.add(values);
							list.add(path);
						bb.put(colNameValue.get(tab.get(index).key)+"", list);
						Write((String)tmp.get((int)myInsert.get(myInsert.size()-1)),bb);
						}
						else if(bb.Overflow.size()==0){
							Bucket b=new Bucket();
							Vector list=new Vector();
							list.add(values);
							list.add(path);
							b.put(colNameValue.get(tab.get(index).key)+"",list); //////// key in bucket is in String fooooorm
							
							bb.Overflow.add("src/main/resources/data/"+tableName+"/"+"Bucket"+myGridindex.number+".class");
							Write((String)tmp.get((int)myInsert.get(myInsert.size()-1)),bb);
							
							Write("src/main/resources/data/"+tableName+"/"+"Bucket"+myGridindex.number+".class",b);
							myGridindex.number++;
						//	tmp.insertElementAt("src/main/resources/data/"+tableName+"/"+"Bucket"+g.number+".class", (int)insert.get(insert.size()-1));
						}else {
							Bucket last=(Bucket)Read((String)bb.Overflow.get(bb.Overflow.size()-1));
							if(last.size()!=maxRow) {
								Vector list=new Vector();
								list.add(values);
								list.add(path);
								last.put(colNameValue.get(tab.get(index).key)+"",list);
								Write((String)bb.Overflow.get(bb.Overflow.size()-1),last);
							}else {
								Bucket b=new Bucket();	
								Vector list=new Vector();
								list.add(values);
								list.add(path);
								b.put(colNameValue.get(tab.get(index).key)+"",list); //////// key in bucket is in String fooooorm
								
								bb.Overflow.add("src/main/resources/data/"+tableName+"/"+"Bucket"+myGridindex.number+".class");
								Write((String)tmp.get((int)myInsert.get(myInsert.size()-1)),bb);
								
								Write("src/main/resources/data/"+tableName+"/"+"Bucket"+myGridindex.number+".class",b);
								myGridindex.number++;
							}
						}
						}
						
						Write(tab.get(index).Gridindex.get(Gridindexlocation),myGridindex);
						 Write("src/main/resources/data/Tabels.class",tab);
				 }
			}
			////////////////////////////////////////////////////////////////////////////////////////
			else {
			
			Object shearchKey=colNameValue.get((tab.get(index).key));
			
			 dataindex =binarySearch(tab.get(index).pages,shearchKey,tab.get(index));
			if(dataindex==-1) {dataindex=tab.get(index).pages.size()-1;
			path =tab.get(index).pages.get(tab.get(index).pages.size()-1).path;}
			else {
			
			path=tab.get(index).pages.get(dataindex).path; 
			}
			}
			Page x =(Page)Read(path);
			
			boolean insert =false;
			int place=0;
			int size=x.size();
			
				for (int i = 0; i <size;i++) {
			
				Hashtable c =(Hashtable)x.elementAt(i);
				String ClusteringKey=tab.get(index).key;
	
				switch (
						(getType(tableName,ClusteringKey))
					) {
					case "java.lang.Integer":
					int	x1 = (int)c.get(ClusteringKey);
					int y1=(int)colNameValue.get(ClusteringKey);
					int	min =(int)tab.get(index).pages.get(dataindex).minValue;
					int max =(int)tab.get(index).pages.get(dataindex).maxValue;
					if(x1>y1) {place =i;insert=true;
					if(y1<min) {tab.get(index).pages.get(dataindex).minValue=y1;}
					if(y1>max) {tab.get(index).pages.get(dataindex).maxValue=y1;}}
						break;
					case "java.lang.String":
					String x2 = (String)c.get(ClusteringKey);
					String y2=(String)colNameValue.get(ClusteringKey);
					String min2 =(String)tab.get(index).pages.get(dataindex).minValue;
					String max2 =(String)tab.get(index).pages.get(dataindex).maxValue;
					if(x2.compareTo(y2)>0) {place =i;insert=true;
					if(y2.compareTo(min2)<0) {tab.get(index).pages.get(dataindex).minValue=y2;}
					if(y2.compareTo(max2)>0) {tab.get(index).pages.get(dataindex).maxValue=y2;}}
						break;
					case "java.lang.Double":
					Double	x3 = (Double)c.get(ClusteringKey);
					Double 	y3=(Double)colNameValue.get(ClusteringKey);
					Double	min3 =(Double)tab.get(index).pages.get(dataindex).minValue;
					Double max3 =(Double)tab.get(index).pages.get(dataindex).maxValue;
					if(x3>y3) {place =i;insert=true;
					if(y3<min3) {tab.get(index).pages.get(dataindex).minValue=y3;}
					if(y3>max3) {tab.get(index).pages.get(dataindex).maxValue=y3;}}
						break;
					case "java.util.Date":
					Date	x4 =((Date)c.get(ClusteringKey));
					Date 	y4=((Date)colNameValue.get(ClusteringKey));
					Date min4 =((Date)tab.get(index).pages.get(dataindex).minValue);
					Date max4 =((Date)tab.get(index).pages.get(dataindex).maxValue);
					if(x4.compareTo(y4)>0) { place =i;insert=true;
					if(y4.compareTo(min4)<0) {tab.get(index).pages.get(dataindex).minValue=y4;}
					if(y4.compareTo(max4)>0) {tab.get(index).pages.get(dataindex).maxValue=y4;}}
						break;
					
					}if(insert) {break;}
			
				}if(!insert) {x.add(colNameValue);tab.get(index).pages.get(dataindex).NumberOfRows++;}
				else {x.insertElementAt(colNameValue,place);tab.get(index).pages.get(dataindex).NumberOfRows++;}
				
				Hashtable min=(Hashtable) x.elementAt(0);
				tab.get(index).pages.get(dataindex).minValue=min.get(tab.get(index).key);
				Hashtable max0=(Hashtable) x.lastElement();
				tab.get(index).pages.get(dataindex).maxValue=max0.get(tab.get(index).key);
				
				Write(path,x);
				Write("src/main/resources/data/Tabels.class",tab);
				
				///////////////////////////////////
			 if(x.size()==maxRow+1 && dataindex==tab.get(index).pages.size()-1) {
				Hashtable tmp =new Hashtable();
				tmp =(Hashtable)x.lastElement();
				x.remove(x.size()-1);
				Hashtable max=(Hashtable) x.lastElement();
				tab.get(index).pages.get(dataindex).maxValue=max.get(tab.get(index).key);
				
				tab.get(index).pages.get(dataindex).NumberOfRows--;
				Write(path,x);
				
				Data data = new Data();
				data.path="src/main/resources/data/"+tableName+"/"+tableName+tab.get(index).number+".class";
				data.minValue=tmp.get(tab.get(index).key);
				data.maxValue=tmp.get(tab.get(index).key);
				data.NumberOfRows++;
				Page page = new Page();
				page.add(tmp);
				
				Write("src/main/resources/data/"+tableName+"/"+tableName+tab.get(index).number+".class",page);
				
				tab.get(index).number++;
				
				tab.get(index).pages.add(data);
				
				Write("src/main/resources/data/Tabels.class",tab);
			
			}
			 else if(x.size()==maxRow+1 && dataindex!=tab.get(index).pages.size()-1) {
				
				 if(tab.get(index).pages.get(dataindex+1).NumberOfRows!=maxRow) {
					 	Hashtable tmp =new Hashtable();
						tmp =(Hashtable)x.lastElement();
						x.remove(x.size()-1);
						Hashtable max=(Hashtable) x.lastElement();
						tab.get(index).pages.get(dataindex).maxValue=max.get(tab.get(index).key);
						
						tab.get(index).pages.get(dataindex).NumberOfRows--;
						Write(path,x);
						
						Page y=(Page)Read(tab.get(index).pages.get(dataindex+1).path);
						y.insertElementAt(tmp, 0);
						tab.get(index).pages.get(dataindex+1).NumberOfRows++;
						Hashtable min2=(Hashtable)y.elementAt(0);
						tab.get(index).pages.get(dataindex+1).minValue=min2.get(tab.get(index).key);
						
						Write(tab.get(index).pages.get(dataindex+1).path,y);
						Write("src/main/resources/data/Tabels.class",tab);
						
				 }
				 else if(tab.get(index).pages.get(dataindex+1).NumberOfRows==maxRow) {
					 	Hashtable tmp =new Hashtable();
						tmp =(Hashtable)x.lastElement();
						x.remove(x.size()-1);
						Hashtable max=(Hashtable) x.lastElement();
						tab.get(index).pages.get(dataindex).maxValue=max.get(tab.get(index).key);
						
						tab.get(index).pages.get(dataindex).NumberOfRows--;
						Write(path,x);
						
						Data data = new Data();
						data.path="src/main/resources/data/"+tableName+"/"+"Overflow"+tab.get(index).number+".class";
						data.minValue=tmp.get(tab.get(index).key);
						data.maxValue=tmp.get(tab.get(index).key);
						data.NumberOfRows++;
						data.OverFlow=true;
						Page page = new Page();
						page.add(tmp);
						
						Write("src/main/resources/data/"+tableName+"/"+"Overflow"+tab.get(index).number+".class",page);
						
						tab.get(index).number++;
						
						tab.get(index).pages.insertElementAt(data, dataindex+1);
						
						tab.get(index).pages.get(dataindex).Flow.add(data);
						
						Write("src/main/resources/data/Tabels.class",tab);
				 }				 
			} 
		}
		
	
	}
	
	public void updateTable(String tableName, String clusteringKeyValue, Hashtable<String, Object> columnNameValue)
			throws DBAppException, NumberFormatException, IOException, ParseException, ClassNotFoundException {
	
		Tabels tab=(Tabels) Read("src/main/resources/data/Tabels.class");
		
		if( tab.size()==0) {throw new DBAppException("Table does not exist");}
		int index=0;
		boolean found1=false;
		for(int i =0 ; i< tab.size();i++) {
		 if(tab.get(i).name.equals(tableName)) {
			  index=i;
			  found1=true;
			  break;
		 }
	 }if(!found1){throw new DBAppException("Table does not exist");}
	 
	 Vector colwithindex=new Vector();//////////////////////////////
	 
	 Enumeration names;
		String key;
		names = columnNameValue.keys();
		while(names.hasMoreElements()) {
			key = (String) names.nextElement();
			///////////////////////////////////////////////////////
			if(checkindex(tableName,key)) {
				colwithindex.add(key);
			}
			//////////////////////////////////////////////////////
			checkCol(tableName,key);
			if((columnNameValue.get(key).getClass().toString()).equals("class"+" "+getType(tableName,key))){
				switch (
						(getType(tableName,key))
					) {
					case "java.lang.Integer":
					int	x1 = Integer.parseInt(getMin(tableName,key));
					int y1=(int)columnNameValue.get(key);
					int z1=Integer.parseInt(getMax(tableName,key));
					if(!(x1<=y1 && z1>=y1)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.lang.String":
					String x2 = getMin(tableName,key);
					String y2=(String)columnNameValue.get(key);
					String z2=getMax(tableName,key);
					if(!(x2.compareTo(y2)<=0 && z2.compareTo(y2)>=0)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.lang.Double":
					Double	x3 = Double.parseDouble(getMin(tableName,key));
					Double  y3=(Double)columnNameValue.get(key);
					Double z3=Double.parseDouble(getMax(tableName,key));
					if(!(x3<=y3 && z3>=y3)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.util.Date":
					Date	x4 = new SimpleDateFormat("yyyy-MM-dd").parse(getMin(tableName,key));
					Date    y4=((Date)columnNameValue.get(key));
					Date 	z4=new SimpleDateFormat("yyyy-MM-dd").parse(getMax(tableName,key));
					if(!(x4.compareTo(y4)<=0 && z4.compareTo(y4)>=0)) {throw new DBAppException("Value is out of range");}
						break;
					}
			}else {throw new DBAppException("Unsupported data type");}
		}			
		Object type=null;	
		switch (
				(getType(tableName,tab.get(index).key))
			) {
			case "java.lang.Integer":
			type=Integer.parseInt(clusteringKeyValue);
				break;
			case "java.lang.String":
			type=(clusteringKeyValue);
				break;
			case "java.lang.Double":
			type=Double.parseDouble(clusteringKeyValue);
				break;
			case "java.util.Date":
			type=(Date)new SimpleDateFormat("yyy-MM-dd").parse("1948-10-17");
				break;
			}
		/////////////////////////////////////////////////////////////////////////////////////////////////

		columnNameValue.put(tab.get(index).key, type);
		
		boolean useindex=false;
		Vector myPath=new Vector();
		myPath.setSize(4);
		boolean updateindex =false;
		Vector myInsert=new Vector();
		Gridindex myGridindex =new Gridindex();
		int Gridindexlocation=0;
		if(colwithindex.size()!=0) {
			
			int count =0;
			int minmum=0;
			for(int i=0;i<tab.get(index).Gridindex.size();i++) {
				count =0;
				Gridindex tmp=(Gridindex)Read(tab.get(index).Gridindex.get(i));
				Vector xx=tmp.indexcol;
				if(xx.contains(tab.get(index).key)) {
					for(int j=0;j<xx.size();j++) {
						if(columnNameValue.containsKey(xx.get(j))) {
							count++;
						}else {
							break;
						}
					}
					if(count > minmum) {
						minmum=count;
						myGridindex=tmp;
						Gridindexlocation=i;
					}
				}
			}
			
			if(count!=0) {
				myPath=FindIndex(tab.get(index),columnNameValue,myGridindex,count);
				if(myPath.get(0)!=null) {useindex=true;}
			}

			
		}
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////
		String path=null;
		///////////////////////////////////////////////////////////////////////////
		int dataindex=0;
		Vector search=new Vector();
		if(useindex) {
			int minindex;
			int maxindex;
			boolean add=false;
			for(int i=0 ;i<tab.get(index).pages.size();i++) {
				if(tab.get(index).pages.get(i).path.equals(myPath.get(0))) {minindex=i; add=true;}
				if(tab.get(index).pages.get(i).path.equals(myPath.get(1))) {maxindex=i; search.add(tab.get(index).pages.get(i).path);add=false; }
			if(add) {search.add(tab.get(index).pages.get(i).path);}
			}
			String bucketpath=(String)myPath.get(3);
			Bucket bucket =(Bucket)Read(bucketpath);
			path=(String) bucket.get(clusteringKeyValue).get(1);
			if(path==null) {throw new DBAppException("tuple does not exixt");} 
		}
		////////////////////////////////////////////////////////////////
		else {
		 dataindex =binarySearchUpdateAndDelete(tab.get(index).pages,type,tab.get(index));

		if(dataindex==-1) {throw new DBAppException("tuple does not exixt");}
		else {

			path=tab.get(index).pages.get(dataindex).path; 
		}
		}
		Page x =(Page)Read(path);
		
		boolean found =false;
		boolean add=false;
		int size=x.size();
			for (int i = 0; i <size;i++) {
			Hashtable c =(Hashtable)x.elementAt(i);
			String ClusteringKey=tab.get(index).key;
			if((c.get(ClusteringKey)).equals(type)) {		
				Enumeration names1;
				String key1;
				names1 = c.keys();
				while(names1.hasMoreElements()) {
					key1 = (String) names1.nextElement();
					
					Enumeration names2;
					String key2;
					names2 = columnNameValue.keys();
					while(names2.hasMoreElements()) {
						key2 = (String) names2.nextElement();
						
						if(key1.equals(key2)) {c.put(key1,columnNameValue.get(key2));}
					
					}
				}
				x.setElementAt(c, i);
				
				Write(path,x);
				
				found =true;
				
				break;
			}
			}if(!found) {throw new DBAppException("tuple does not exixt");} 
	

	}
	
	public void deleteFromTable(String tableName, Hashtable<String, Object> columnNameValue) throws DBAppException, IOException, ParseException, ClassNotFoundException {

		Tabels tab=(Tabels) Read("src/main/resources/data/Tabels.class");
		
		if( tab.size()==0) {throw new DBAppException("Table does not exist");}
		int index=0;
		boolean found=false;
		for(int i =0 ; i< tab.size();i++) {
		 if(tab.get(i).name.equals(tableName)) {
			  index=i;
			  found=true;
			  break;
		 }
	 }if(!found){throw new DBAppException("Table does not exist");}
	 
	 Vector colwithindex=new Vector();//////////////////////////////
	 
	 boolean KeyExist =false;
	 Object find =null;

	 
		Enumeration names;
		String key;
		names = columnNameValue.keys();
		while(names.hasMoreElements()) {
			key = (String) names.nextElement();
			///////////////////////////////////////////////////////
			if(checkindex(tableName,key)) {
				colwithindex.add(key);
			}
			//////////////////////////////////////////////////////
			checkCol(tableName,key);
			if(key.equals(tab.get(index).key)) {KeyExist=true; find =columnNameValue.get(tab.get(index).key);break;}
		}
		
		if(KeyExist) {
			//////////////////////////////////////////////////////////
			boolean useindex=false;
			Vector myPath=new Vector();
			myPath.setSize(3);
			boolean updateindex =false;
			Vector myInsert=new Vector();
			Gridindex myGridindex =new Gridindex();
			int Gridindexlocation=0;
			if(colwithindex.size()!=0) {
				
				int count =0;
				int minmum=0;
				for(int i=0;i<tab.get(index).Gridindex.size();i++) {
					count =0;
					Gridindex tmp=(Gridindex)Read(tab.get(index).Gridindex.get(i));
					Vector xx=tmp.indexcol;
					if(xx.contains(tab.get(index).key)) {
						for(int j=0;j<xx.size();j++) {
							if(columnNameValue.containsKey(xx.get(j))) {
								count++;
							}else {
								break;
							}
						}
						if(count > minmum) {
							minmum=count;
							myGridindex=tmp;
							Gridindexlocation=i;
						}
					}
				}
				if(count!=0) {
					myPath=FindIndex(tab.get(index),columnNameValue,myGridindex,count);
					if(myPath.get(0)!=null) {useindex=true;}
					myInsert=(Vector)myPath.get(2);
					if(myInsert!=null) {
						updateindex=true;
					}
				}

				
			}
			///////////////////////////////////////////////////////
			
			String path=null;
			//////////////////////////////////////////////////////
			int dataindex=0;
			Vector search=new Vector();
			if(useindex) {
				int minindex;
				int maxindex;
				boolean add=false;
				for(int i=0 ;i<tab.get(index).pages.size();i++) {
					if(tab.get(index).pages.get(i).path.equals(myPath.get(0))) {minindex=i; add=true;}
					if(tab.get(index).pages.get(i).path.equals(myPath.get(1))) {maxindex=i; search.add(tab.get(index).pages.get(i).path);add=false; }
				if(add) {search.add(tab.get(index).pages.get(i).path);}
				}
				String bucketpath=(String)myPath.get(3);
				Bucket bucket =(Bucket)Read(bucketpath);
				path=(String) bucket.get(columnNameValue.get(tab.get(index).key)+"").get(1);
				
				if(path==null) {throw new DBAppException("tuple does not exixt");}

				 
				 if(updateindex) {
						bucket.remove(columnNameValue.get(tab.get(index).key)+"");
						Write(bucketpath,bucket);
						
				//		Write(tab.get(index).Gridindex.get(Gridindexlocation),myGridindex);
				//		 Write("src/main/resources/data/Tabels.class",tab);
				 }
			}
			//////////////////////////////////////////////////////
			else {
			dataindex =binarySearchUpdateAndDelete(tab.get(index).pages,find,tab.get(index));
			
			if(dataindex==-1) {throw new DBAppException("tuple does not exixt");}
			else {

				path=tab.get(index).pages.get(dataindex).path; 
			}
			}
			Page x =(Page)Read(path);
			
			int size=x.size();
			for(int i=0; i<x.size();i++) {
				Hashtable delete =(Hashtable) x.get(i);
				if(delete.get(tab.get(index).key).equals(find)) {
					x.remove(i);
					tab.get(index).clusteringKeys.removeElement(find);
					if(x.size()==0) {
						File file = new File(path);
						file.delete();
						if(tab.get(index).pages.get(dataindex).OverFlow=true) {
							tab.get(index).pages.get(dataindex-1).Flow.removeElement(tab.get(index).pages.get(dataindex));
						}	
						tab.get(index).pages.remove(i);
					}else {
					Hashtable min =(Hashtable) x.elementAt(0);
					tab.get(index).pages.get(dataindex).minValue=min.get(tab.get(index).key);
					Hashtable max =(Hashtable) x.elementAt(x.size()-1);
					tab.get(index).pages.get(dataindex).maxValue=max.get(tab.get(index).key);
					
					Write(path,x);
					}
					break;
				}
			}
			Write("src/main/resources/data/Tabels.class",tab);
		}
		else {
			String path=null;
			for(int i =0;i<tab.get(index).pages.size();i++) {
				path=tab.get(index).pages.get(i).path;
				Page x =(Page)Read(path);
				for(int j=0;j<x.size();j++) {
					boolean yalla=true;
					Hashtable delete =(Hashtable) x.get(j);
					Enumeration names1;
					String key1;
					names1 = columnNameValue.keys();
					while(names1.hasMoreElements()) {
						key1 = (String) names1.nextElement();
						if(!(columnNameValue.get(key1).equals(delete.get(key1)))) {yalla=false;}
						
					}
					if(yalla) {
						x.remove(j);
						tab.get(index).clusteringKeys.removeElement(delete.get(tab.get(index).key));
						j--;
					}
					if(x.size()==0) {
						File file = new File(path);
						file.delete();
						if(tab.get(index).pages.get(i).OverFlow==true) {
							tab.get(index).pages.get(i-1).Flow.removeElement(tab.get(index).pages.get(i));
						}	
						tab.get(index).pages.remove(i);
						i--;
						if(tab.get(index).pages.size()==0) {
							File file1 = new File("src/main/resources/data/"+tableName);
							file1.delete();
						}
					}else {
						Hashtable min =(Hashtable) x.elementAt(0);
						tab.get(index).pages.get(i).minValue=min.get(tab.get(index).key);
						Hashtable max =(Hashtable) x.elementAt(x.size()-1);
						tab.get(index).pages.get(i).maxValue=max.get(tab.get(index).key);
						Write(path,x);
					}
				}
			}
			Write("src/main/resources/data/Tabels.class",tab);
		}
	}
	
	public Iterator selectFromTable(SQLTerm[] sqlTerms, String[] arrayOperators) throws DBAppException, ClassNotFoundException, IOException, ParseException {
		Tabels tab=(Tabels) Read("src/main/resources/data/Tabels.class");
		
		if( tab.size()==0) {throw new DBAppException("Table does not exist");}
		int index=0;
		boolean found1=false;
		for(int i =0 ; i< tab.size();i++) {
		 if(tab.get(i).name.equals(sqlTerms[0]._strTableName)) {
			  index=i;
			  found1=true;
			  break;
		 }
	 }if(!found1){throw new DBAppException("Table does not exist");}
		
	 for(int i=0;i<sqlTerms.length;i++) {
			checkCol(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
			if((sqlTerms[i]._objValue.getClass().toString()).equals("class"+" "+getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName))){
				switch (
						(getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName))
					) {
					case "java.lang.Integer":
					int	x1 = Integer.parseInt(getMin(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName));
					int y1=(int)sqlTerms[i]._objValue;
					int z1=Integer.parseInt(getMax(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName));
					if(!(x1<=y1 && z1>=y1)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.lang.String":
					String x2 = getMin(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
					String y2=(String)sqlTerms[i]._objValue;
					String z2=getMax(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
					if(!(x2.compareTo(y2)<=0 && z2.compareTo(y2)>=0)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.lang.Double":
					Double	x3 = Double.parseDouble(getMin(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName));
					Double  y3=(Double)sqlTerms[i]._objValue;
					Double z3=Double.parseDouble(getMax(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName));
					if(!(x3<=y3 && z3>=y3)) {throw new DBAppException("Value is out of range");}
						break;
					case "java.util.Date":
					Date	x4 = new SimpleDateFormat("yyyy-MM-dd").parse(getMin(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName));
					Date    y4=(Date)sqlTerms[i]._objValue;
					Date 	z4=new SimpleDateFormat("yyyy-MM-dd").parse(getMax(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName));
					if(!(x4.compareTo(y4)<=0 && z4.compareTo(y4)>=0)) {throw new DBAppException("Value is out of range");}
						break;
					}
			}else {throw new DBAppException("Unsupported data type");}
	 }
	 Vector result =new Vector();
	 
	 for(int i =0;i<sqlTerms.length;i++) {
		 Vector output =new Vector();
	
		 Gridindex myGridindex =new Gridindex();
		 int Gridindexlocation=0;
		 boolean useindex =false;
		 
		 if(checkindex(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName)) {
				for(int j=0;j<tab.get(index).Gridindex.size();j++) {
					
						Gridindex tmp=(Gridindex)Read(tab.get(index).Gridindex.get(j));
						Vector xx=tmp.indexcol;
						
						if(xx.size()==1 && xx.get(0).equals(sqlTerms[i]._strColumnName)) {
							
							myGridindex=tmp;
							Gridindexlocation=i;
							useindex=true;
							break;
							}
						}
					}
		 if(useindex) {
			 int location=0;
			 boolean found =false;
			 for(int j=0;j<10;j++) {
					switch (
							(getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName))
						) {
						case "java.lang.Integer":
							if(j==9) {if((int)myGridindex.indexColRange.get(0).get(j).max>=(int)sqlTerms[i]._objValue && (int)myGridindex.indexColRange.get(0).get(j).min<=(int)sqlTerms[i]._objValue)
								location =j;found=true;}else {
									if((int)myGridindex.indexColRange.get(0).get(j).max>(int)sqlTerms[i]._objValue && (int)myGridindex.indexColRange.get(0).get(j).min<=(int)sqlTerms[i]._objValue)
										location =j;found=true;}
							break;
						case "java.lang.String":
							String a=(String)myGridindex.indexColRange.get(0).get(j).max;
							String b=(String)myGridindex.indexColRange.get(0).get(j).min;
							if(j==9) {if(a.compareTo((String)sqlTerms[i]._objValue)>=0 && b.compareTo((String)sqlTerms[i]._objValue)<=0) {
								location =j;found=true;
							}}else {
								if(a.compareTo((String)sqlTerms[i]._objValue)>=0 && b.compareTo((String)sqlTerms[i]._objValue)<=0) {
									location =j;found=true;
							}}
							break;
						case "java.lang.Double":
							if(j==9) {if((Double)myGridindex.indexColRange.get(0).get(j).max>=(Double)sqlTerms[i]._objValue && (Double)myGridindex.indexColRange.get(i).get(j).min<=(Double)sqlTerms[i]._objValue)
								location =j;found=true;}else {
							if((Double)myGridindex.indexColRange.get(0).get(j).max>(Double)sqlTerms[i]._objValue && (Double)myGridindex.indexColRange.get(i).get(j).min<=(Double)sqlTerms[i]._objValue)
								location =j;found=true;}
							break;
						case "java.util.Date":
							Date aa=(Date)myGridindex.indexColRange.get(0).get(j).max;
							Date bb=(Date)myGridindex.indexColRange.get(0).get(j).min;
							if(j==9) {if(aa.compareTo((Date)sqlTerms[i]._objValue)>=0 && bb.compareTo((Date)sqlTerms[i]._objValue)<=0) {
								location =j;found=true;
							}}else {
							if(aa.compareTo((Date)sqlTerms[i]._objValue)>=0 && bb.compareTo((Date)sqlTerms[i]._objValue)<=0) {
								location =j;found=true;
							}}
							break;
						}
				}
			 
			 if(found) {
				 Bucket bucket =(Bucket)Read((String)myGridindex.get(location));
				 
				 switch(sqlTerms[i]._strOperator) 
				 {
				 case "=":
					 if(true) {
					 String path=null;
					 if(true) {
					 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
						  String key = entry.getKey();
						  Vector value = entry.getValue();
						  Vector x=(Vector)value.get(0);
						  if(x.get(0).equals(sqlTerms[i]._objValue)) {
							  path=(String)value.get(1);
						  
						  Page p=(Page)Read(path);
						  for(int k=0;k<p.size();k++) {
							  Hashtable hash=(Hashtable)p.get(k);
							  Enumeration names;
								String key1;
								names = hash.keys();
								while(names.hasMoreElements()) {
									key1 = (String) names.nextElement();
									if(key1.equals(sqlTerms[i]._strColumnName)&&sqlTerms[i]._objValue.equals(hash.get(key1))) {
										output.add(hash);
									}
								}
						  }
					 }
						 }
						}
					 for(int q=0; q<bucket.Overflow.size();q++) {
							Bucket tmp =(Bucket)Read(bucket.Overflow.get(q));
							for(Map.Entry<String,Vector> entry : tmp.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								  if(x.get(0).equals(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
								  
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)&&sqlTerms[i]._objValue.equals(hash.get(key1))) {
												output.add(hash);
											}
										}
								  }
							}
								 }
					 }
					 }
					 
					 break;
				 case ">":
					 if(true) {
						 String path=null;
					for(int a=location ;a<10;a++) {
						if(true) {
							 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
								  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									  if((double)x.get(0)>(double)(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
									  }
								  }else if(type.equals("java.lang.String")) {
									  String m=(String)x.get(0);
									  String n=(String)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>0) {
										  path=(String)value.get(1);
									  }
								  }else {
									  Date m=(Date)x.get(0);
									  Date n=(Date)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>0) {
										  path=(String)value.get(1);
									  }
								  }
								 if(path!=null) {
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)) {
											if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
											if((double)sqlTerms[i]._objValue>(double)(hash.get(key1))) {
												output.add(hash);
											}
											}else if(type.equals("java.lang.String")) {
												  String m=(String)hash.get(key1);
												  String n=(String)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>0) {
													  output.add(hash);
												  }
											  }else {
												  Date m=(Date)hash.get(key1);
												  Date n=(Date)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>0) {
													  output.add(hash);
												  }
											  }
											}
										}
								  }
							 }
								 }
								}
						 for(int q=0; q<bucket.Overflow.size();q++) {
							 Bucket tmp =(Bucket)Read(bucket.Overflow.get(q));
							 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
								  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									  if((double)x.get(0)>(double)(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
									  }
								  }else if(type.equals("java.lang.String")) {
									  String m=(String)x.get(0);
									  String n=(String)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>0) {
										  path=(String)value.get(1);
									  }
								  }else {
									  Date m=(Date)x.get(0);
									  Date n=(Date)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>0) {
										  path=(String)value.get(1);
									  }
								  }
								 if(path!=null) {
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)) {
											if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
											if((double)sqlTerms[i]._objValue>(double)(hash.get(key1))) {
												output.add(hash);
											}
											}else if(type.equals("java.lang.String")) {
												  String m=(String)hash.get(key1);
												  String n=(String)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>0) {
													  output.add(hash);
												  }
											  }else {
												  Date m=(Date)hash.get(key1);
												  Date n=(Date)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>0) {
													  output.add(hash);
												  }
											  }
											}
										}
								  }
							 }
								 }
						 }
						
					}
				
					 }
					 break;
				 case ">=":
					 if(true) {
						 String path=null;
					for(int a=location ;a<10;a++) {
						if(true) {
							 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
								  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									  if((double)x.get(0)>=(double)(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
									  }
								  }else if(type.equals("java.lang.String")) {
									  String m=(String)x.get(0);
									  String n=(String)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>=0) {
										  path=(String)value.get(1);
									  }
								  }else {
									  Date m=(Date)x.get(0);
									  Date n=(Date)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>=0) {
										  path=(String)value.get(1);
									  }
								  }
								 if(path!=null) {
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)) {
											if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
											if((double)sqlTerms[i]._objValue>=(double)(hash.get(key1))) {
												output.add(hash);
											}
											}else if(type.equals("java.lang.String")) {
												  String m=(String)hash.get(key1);
												  String n=(String)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>=0) {
													  output.add(hash);
												  }
											  }else {
												  Date m=(Date)hash.get(key1);
												  Date n=(Date)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>=0) {
													  output.add(hash);
												  }
											  }
											}
										}
								  }
							 }
								 }
								}
						 for(int q=0; q<bucket.Overflow.size();q++) {
							 Bucket tmp =(Bucket)Read(bucket.Overflow.get(q));
							 for(Map.Entry<String,Vector> entry : tmp.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
								  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									  if((double)x.get(0)>=(double)(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
									  }
								  }else if(type.equals("java.lang.String")) {
									  String m=(String)x.get(0);
									  String n=(String)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>=0) {
										  path=(String)value.get(1);
									  }
								  }else {
									  Date m=(Date)x.get(0);
									  Date n=(Date)sqlTerms[i]._objValue;
									  if(m.compareTo(n)>=0) {
										  path=(String)value.get(1);
									  }
								  }
								 if(path!=null) {
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)) {
											if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
											if((double)sqlTerms[i]._objValue>=(double)(hash.get(key1))) {
												output.add(hash);
											}
											}else if(type.equals("java.lang.String")) {
												  String m=(String)hash.get(key1);
												  String n=(String)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>=0) {
													  output.add(hash);
												  }
											  }else {
												  Date m=(Date)hash.get(key1);
												  Date n=(Date)sqlTerms[i]._objValue;
												  if(m.compareTo(n)>=0) {
													  output.add(hash);
												  }
											  }
											}
										}
								  }
							 }
								 }
						 }
						
					}
				
					 }
					 break;
				 case "<":
						 if(true) {
							 String path=null;
						for(int a=0 ;a<location;a++) {
							if(true) {
								 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
									  String key = entry.getKey();
									  Vector value = entry.getValue();
									  Vector x=(Vector)value.get(0);
									 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
									  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
										  if((double)x.get(0)<(double)(sqlTerms[i]._objValue)) {
										  path=(String)value.get(1);
										  }
									  }else if(type.equals("java.lang.String")) {
										  String m=(String)x.get(0);
										  String n=(String)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<0) {
											  path=(String)value.get(1);
										  }
									  }else {
										  Date m=(Date)x.get(0);
										  Date n=(Date)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<0) {
											  path=(String)value.get(1);
										  }
									  }
									 if(path!=null) {
									  Page p=(Page)Read(path);
									  for(int k=0;k<p.size();k++) {
										  Hashtable hash=(Hashtable)p.get(k);
										  Enumeration names;
											String key1;
											names = hash.keys();
											while(names.hasMoreElements()) {
												key1 = (String) names.nextElement();
												if(key1.equals(sqlTerms[i]._strColumnName)) {
												if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
												if((double)sqlTerms[i]._objValue<(double)(hash.get(key1))) {
													output.add(hash);
												}
												}else if(type.equals("java.lang.String")) {
													  String m=(String)hash.get(key1);
													  String n=(String)sqlTerms[i]._objValue;
													  if(m.compareTo(n)<0) {
														  output.add(hash);
													  }
												  }else {
													  Date m=(Date)hash.get(key1);
													  Date n=(Date)sqlTerms[i]._objValue;
													  if(m.compareTo(n)<0) {
														  output.add(hash);
													  }
												  }
												}
											}
									  }
								 }
									 }
									}
							 for(int q=0; q<bucket.Overflow.size();q++) {
								 Bucket tmp =(Bucket)Read(bucket.Overflow.get(q));
								 for(Map.Entry<String,Vector> entry : tmp.entrySet()) {
									  String key = entry.getKey();
									  Vector value = entry.getValue();
									  Vector x=(Vector)value.get(0);
									 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
									  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
										  if((double)x.get(0)<(double)(sqlTerms[i]._objValue)) {
										  path=(String)value.get(1);
										  }
									  }else if(type.equals("java.lang.String")) {
										  String m=(String)x.get(0);
										  String n=(String)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<0) {
											  path=(String)value.get(1);
										  }
									  }else {
										  Date m=(Date)x.get(0);
										  Date n=(Date)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<0) {
											  path=(String)value.get(1);
										  }
									  }
									 if(path!=null) {
									  Page p=(Page)Read(path);
									  for(int k=0;k<p.size();k++) {
										  Hashtable hash=(Hashtable)p.get(k);
										  Enumeration names;
											String key1;
											names = hash.keys();
											while(names.hasMoreElements()) {
												key1 = (String) names.nextElement();
												if(key1.equals(sqlTerms[i]._strColumnName)) {
												if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
												if((double)sqlTerms[i]._objValue<(double)(hash.get(key1))) {
													output.add(hash);
												}
												}else if(type.equals("java.lang.String")) {
													  String m=(String)hash.get(key1);
													  String n=(String)sqlTerms[i]._objValue;
													  if(m.compareTo(n)<0) {
														  output.add(hash);
													  }
												  }else {
													  Date m=(Date)hash.get(key1);
													  Date n=(Date)sqlTerms[i]._objValue;
													  if(m.compareTo(n)<0) {
														  output.add(hash);
													  }
												  }
												}
											}
									  }
								 }
									 }
							 }
							
						}
					
						 } 
					 break;
				 case "<=":
					 if(true) {
						 String path=null;
					for(int a=0 ;a<location;a++) {
						if(true) {
							 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
								  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									  if((double)x.get(0)<=(double)(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
									  }
								  }else if(type.equals("java.lang.String")) {
									  String m=(String)x.get(0);
									  String n=(String)sqlTerms[i]._objValue;
									  if(m.compareTo(n)<=0) {
										  path=(String)value.get(1);
									  }
								  }else {
									  Date m=(Date)x.get(0);
									  Date n=(Date)sqlTerms[i]._objValue;
									  if(m.compareTo(n)<=0) {
										  path=(String)value.get(1);
									  }
								  }
								 if(path!=null) {
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)) {
											if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
											if((double)sqlTerms[i]._objValue<=(double)(hash.get(key1))) {
												output.add(hash);
											}
											}else if(type.equals("java.lang.String")) {
												  String m=(String)hash.get(key1);
												  String n=(String)sqlTerms[i]._objValue;
												  if(m.compareTo(n)<=0) {
													  output.add(hash);
												  }
											  }else {
												  Date m=(Date)hash.get(key1);
												  Date n=(Date)sqlTerms[i]._objValue;
												  if(m.compareTo(n)<=0) {
													  output.add(hash);
												  }
											  }
											}
										}
								  }
							 }
								 }
								}
						 for(int q=0; q<bucket.Overflow.size();q++) {
							 Bucket tmp =(Bucket)Read(bucket.Overflow.get(q));
							 for(Map.Entry<String,Vector> entry : tmp.entrySet()) {
								  String key = entry.getKey();
								  Vector value = entry.getValue();
								  Vector x=(Vector)value.get(0);
								 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
								  if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									  if((double)x.get(0)<=(double)(sqlTerms[i]._objValue)) {
									  path=(String)value.get(1);
									  }
								  }else if(type.equals("java.lang.String")) {
									  String m=(String)x.get(0);
									  String n=(String)sqlTerms[i]._objValue;
									  if(m.compareTo(n)<=0) {
										  path=(String)value.get(1);
									  }
								  }else {
									  Date m=(Date)x.get(0);
									  Date n=(Date)sqlTerms[i]._objValue;
									  if(m.compareTo(n)<=0) {
										  path=(String)value.get(1);
									  }
								  }
								 if(path!=null) {
								  Page p=(Page)Read(path);
								  for(int k=0;k<p.size();k++) {
									  Hashtable hash=(Hashtable)p.get(k);
									  Enumeration names;
										String key1;
										names = hash.keys();
										while(names.hasMoreElements()) {
											key1 = (String) names.nextElement();
											if(key1.equals(sqlTerms[i]._strColumnName)) {
											if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
											if((double)sqlTerms[i]._objValue<=(double)(hash.get(key1))) {
												output.add(hash);
											}
											}else if(type.equals("java.lang.String")) {
												  String m=(String)hash.get(key1);
												  String n=(String)sqlTerms[i]._objValue;
												  if(m.compareTo(n)<=0) {
													  output.add(hash);
												  }
											  }else {
												  Date m=(Date)hash.get(key1);
												  Date n=(Date)sqlTerms[i]._objValue;
												  if(m.compareTo(n)<=0) {
													  output.add(hash);
												  }
											  }
											}
										}
								  }
							 }
								 }
						 }
						
					}
				
					 } 
					 break;
				 case "!=":
					 if(true) {
						 String path=null;
						 if(true) {
						 for(Map.Entry<String,Vector> entry : bucket.entrySet()) {
							  String key = entry.getKey();
							  Vector value = entry.getValue();
							  Vector x=(Vector)value.get(0);
							  if(!(x.get(0).equals(sqlTerms[i]._objValue))) {
								  path=(String)value.get(1);
							  
							  Page p=(Page)Read(path);
							  for(int k=0;k<p.size();k++) {
								  Hashtable hash=(Hashtable)p.get(k);
								  Enumeration names;
									String key1;
									names = hash.keys();
									while(names.hasMoreElements()) {
										key1 = (String) names.nextElement();
										if(key1.equals(sqlTerms[i]._strColumnName)&&!(sqlTerms[i]._objValue.equals(hash.get(key1)))) {
											output.add(hash);
										}
									}
							  }
						 }
							 }
							}
						 for(int q=0; q<bucket.Overflow.size();q++) {
								Bucket tmp =(Bucket)Read(bucket.Overflow.get(q));
								for(Map.Entry<String,Vector> entry : tmp.entrySet()) {
									  String key = entry.getKey();
									  Vector value = entry.getValue();
									  Vector x=(Vector)value.get(0);
									  if(!(x.get(0).equals(sqlTerms[i]._objValue))) {
										  path=(String)value.get(1);
									  
									  Page p=(Page)Read(path);
									  for(int k=0;k<p.size();k++) {
										  Hashtable hash=(Hashtable)p.get(k);
										  Enumeration names;
											String key1;
											names = hash.keys();
											while(names.hasMoreElements()) {
												key1 = (String) names.nextElement();
												if(key1.equals(sqlTerms[i]._strColumnName)&&!(sqlTerms[i]._objValue.equals(hash.get(key1)))) {
													output.add(hash);
												}
											}
									  }
								}
									 }
						 }
						 }
					 break;
					 
				 }
				 
				 result.add(output);
				 
			 }else {
			//	 result.add(null);
			 }
			 
		 }else {
			 String type= getType(sqlTerms[i]._strTableName,sqlTerms[i]._strColumnName);
			 for(int t=0;t<tab.get(index).pages.size();t++) {
				 Page p=(Page)Read(tab.get(index).pages.get(t).path);
				 for(int r=0;r<p.size();r++) {
					 Hashtable hash =(Hashtable)p.get(r);
					 switch(sqlTerms[i]._strOperator)
					 {
					 case "=":
						 if(true) {
							 Enumeration names;
								String key1;
								names = hash.keys();
								while(names.hasMoreElements()) {
									key1 = (String) names.nextElement();
									if(key1.equals(sqlTerms[i]._strColumnName)&&(sqlTerms[i]._objValue.equals(hash.get(key1)))) {
										output.add(hash);
									}
								}
						 }
						 break;
					 case ">":
						 if(true) {
							 Enumeration names;
								String key1;
								names = hash.keys();
								while(names.hasMoreElements()) {
									key1 = (String) names.nextElement();
									if(key1.equals(sqlTerms[i]._strColumnName)) {
									if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									if((double)sqlTerms[i]._objValue>(double)(hash.get(key1))) {
										output.add(hash);
									}
									}else if(type.equals("java.lang.String")) {
										  String m=(String)hash.get(key1);
										  String n=(String)sqlTerms[i]._objValue;
										  if(m.compareTo(n)>0) {
											  output.add(hash);
										  }
									  }else {
										  Date m=(Date)hash.get(key1);
										  Date n=(Date)sqlTerms[i]._objValue;
										  if(m.compareTo(n)>0) {
											  output.add(hash);
										  }
									  }
									}
								}
						 }
						 break;
					 case ">=":
						 if(true) {
							 Enumeration names;
								String key1;
								names = hash.keys();
								while(names.hasMoreElements()) {
									key1 = (String) names.nextElement();
									if(key1.equals(sqlTerms[i]._strColumnName)) {
									if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									if((double)sqlTerms[i]._objValue>=(double)(hash.get(key1))) {
										output.add(hash);
									}
									}else if(type.equals("java.lang.String")) {
										  String m=(String)hash.get(key1);
										  String n=(String)sqlTerms[i]._objValue;
										  if(m.compareTo(n)>=0) {
											  output.add(hash);
										  }
									  }else {
										  Date m=(Date)hash.get(key1);
										  Date n=(Date)sqlTerms[i]._objValue;
										  if(m.compareTo(n)>=0) {
											  output.add(hash);
										  }
									  }
									}
								}
						 }
						 break;
					 case "<":
						 if(true) {
							 Enumeration names;
								String key1;
								names = hash.keys();
								while(names.hasMoreElements()) {
									key1 = (String) names.nextElement();
									if(key1.equals(sqlTerms[i]._strColumnName)) {
									if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									if((double)sqlTerms[i]._objValue<(double)(hash.get(key1))) {
										output.add(hash);
									}
									}else if(type.equals("java.lang.String")) {
										  String m=(String)hash.get(key1);
										  String n=(String)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<0) {
											  output.add(hash);
										  }
									  }else {
										  Date m=(Date)hash.get(key1);
										  Date n=(Date)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<0) {
											  output.add(hash);
										  }
									  }
									}
								} 
						 }
						 break;
					 case "<=":
						 if(true) {
							 Enumeration names;
								String key1;
								names = hash.keys();
								while(names.hasMoreElements()) {
									key1 = (String) names.nextElement();
									if(key1.equals(sqlTerms[i]._strColumnName)) {
									if(type.equals("java.lang.Integer")||(type.equals("java.lang.Double"))){
									if((double)sqlTerms[i]._objValue<=(double)(hash.get(key1))) {
										output.add(hash);
									}
									}else if(type.equals("java.lang.String")) {
										  String m=(String)hash.get(key1);
										  String n=(String)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<=0) {
											  output.add(hash);
										  }
									  }else {
										  Date m=(Date)hash.get(key1);
										  Date n=(Date)sqlTerms[i]._objValue;
										  if(m.compareTo(n)<=0) {
											  output.add(hash);
										  }
									  }
									}
								}
						 }
						 break;
					 case "!=":
						 if(true) {
						 Enumeration names;
							String key1;
							names = hash.keys();
							while(names.hasMoreElements()) {
								key1 = (String) names.nextElement();
								if(key1.equals(sqlTerms[i]._strColumnName)&&!(sqlTerms[i]._objValue.equals(hash.get(key1)))) {
									output.add(hash);
								}
							}
						 }
						 break;
					 }
				 }
			 }
		 }
		 
			 
	 
			
	 }
	 
	 if(result.size()!=0) {
		 Vector first =(Vector)result.get(0);
		 switch(arrayOperators[0])
		 {
		 case "AND":
			 if(true) {
				 for(int s=0;s<result.size()-1;s++) {
					first.retainAll((Vector)result.get(s+1)); 
				 }
				 return first.iterator();
				 
			 }
			 break;
		 case "OR":
			 if(true) {
				 for(int s=0;s<result.size()-1;s++) {
					 Vector next =(Vector)result.get(s+1);
					 for(int t=0;t<next.size();t++) {
						if(!(first.contains(next.get(t)))) {
						first.add(next.get(t));
						}
						}
						
					 }
					 return first.iterator();
			 }
			 break;
		 case "XOR":
			 if(true) {
				 Vector tmp=new Vector();
				 tmp.addAll(first);
				 for(int s=0;s<result.size()-1;s++) {
					 tmp.retainAll((Vector)result.get(s+1)); 
					 }
	
				 for(int s=0;s<result.size()-1;s++) {
					 Vector next =(Vector)result.get(s+1);
					 for(int t=0;t<next.size();t++) {
						if(!(first.contains(next.get(t)))) {
						first.add(next.get(t));
						}
						}
						
					 }
				 for(int c=0;c<tmp.size();c++) {
					 if(first.contains(tmp.get(c))) {
						 first.remove(tmp.get(c));
					 }
				 }
				 return first.iterator();
				 
			 }
			 break;
		 }
		 
		 
		 
 
		 
	 }else {
		 return null;
	 }
		
		

		
		return null;
	}
	
	public static String getType (String tableName , String col) throws IOException {
		 String row;
		 BufferedReader csvReader = new BufferedReader(new FileReader("src/main/resources/metadata.csv"));
		 while ((row = csvReader.readLine()) != null) {
		     String[] data = row.split(",");
		if(data[0].equals(tableName) && data[1].equals(col) ) {
			csvReader.close();
			return  data[2];
		}
		 }
		 csvReader.close();
		return "";
		 
	}
	
	public static String getMin (String tableName , String col) throws IOException{
		 String row;
		 BufferedReader csvReader = new BufferedReader(new FileReader("src/main/resources/metadata.csv"));
		 while ((row = csvReader.readLine()) != null) {
		     String[] data = row.split(",");
		if(data[0].equals(tableName) && data[1].equals(col) ) {
			csvReader.close();
			return  data[5];
		}
		 }
		 csvReader.close();
		return "";
	}
	
	public static String getMax (String tableName , String col) throws IOException{
		 String row;
		 BufferedReader csvReader = new BufferedReader(new FileReader("src/main/resources/metadata.csv"));
		 while ((row = csvReader.readLine()) != null) {
		     String[] data = row.split(",");
		if(data[0].equals(tableName) && data[1].equals(col) ) {
			csvReader.close();
			return  data[6];
		}
		 }
		 csvReader.close();
		return "";
	}
	
	public static int binarySearch(Vector<Data> arr, Object x,  Tabel y ) throws IOException, ParseException
    {
        int l = 0, r = arr.size() - 1;
       
        while (l <= r) {
        	 boolean done = false;
            int m = l + (r - l) / 2;
            if(arr.size()==1) {return 0;}
            else if(m==0) {
            	switch (
    					(getType(y.name,y.key))
    				) {
    				case "java.lang.Integer":
    				int y1=(int)(x);
    				int	min1 =(int)(y.pages.get(m).minValue);
    				int max1 =(int)(y.pages.get(m).maxValue);
    				if(y1<=min1) { done=true;}
    				if(y1>=min1 && y1 <= max1) {done=true;}    
    					break;
    				case "java.lang.String":
    				String y2=(String)x;
    				String min2 =(String)(y.pages.get(m).minValue);
    				String max2 =(String)(y.pages.get(m).maxValue);
    				if(y2.compareTo(min2)<=0) {done=true;}
    				if(y2.compareTo(min2)>=0&&y2.compareTo(max2)<=0) {done=true;}
    					break;
    				case "java.lang.Double":
    				Double 	y3=(Double)(x);
    				Double	min3 =(Double)(y.pages.get(m).minValue);
    				Double max3 =(Double)(y.pages.get(m).maxValue);
    				if(y3<=min3) {done=true;}
    				if(y3>=min3 && y3 <=max3) {done=true;}
    					break;
    				case "java.util.Date":
    				Date 	y4=(Date)(x);
    				Date min4 =((Date)y.pages.get(m).minValue);
    				Date max4 =((Date) y.pages.get(m).maxValue);
   				if(y4.compareTo(min4)<=0) {done=true;}
    				if(y4.compareTo(min4)>=0&&y4.compareTo(max4)<=0) {done=true;}
    					break;
    				
    				}
            }else {
            switch (
					(getType(y.name,y.key))
				) {
				case "java.lang.Integer":
				int y1=(int)(x);
				int	min1 =(int)(y.pages.get(m).minValue);
				int max1 =(int)(y.pages.get(m).maxValue);
				int maxLpage1=(int)(y.pages.get(m-1).maxValue);
				if(m!=arr.size() - 1 && y.pages.get(m).NumberOfRows!=maxRow) {
				int minNpage=(int)(y.pages.get(m+1).minValue);
				if(y1>=min1 && y1<=minNpage) {done=true;}
				}
				if(y1<=min1 && y1>=maxLpage1) { done=true;} /////
				if(y1>=min1 && y1<= max1) {done=true;}  
				if(y1>=max1 && m==arr.size() - 1) {done=true;}
				
					break;
				case "java.lang.String":
				String y2=(String)x;
				String min2 =(String)(y.pages.get(m).minValue);
				String max2 =(String)(y.pages.get(m).maxValue);
				String maxLpage2=(String)(y.pages.get(m-1).maxValue);
				if(m!=arr.size() - 1) {
					String minNpage=(String)(y.pages.get(m+1).minValue);
					if(y2.compareTo(min2)>=0 && y2.compareTo(minNpage)<=0) {done=true;}
					}
				if(y2.compareTo(min2)<=0 &&y2.compareTo(maxLpage2)>=0) {done=true;}
				if(y2.compareTo(min2)>=0 &&y2.compareTo(max2)<=0) {done=true;}
				if(y2.compareTo(max2)>=0 && m==arr.size() - 1) {done=true;}
					break;
				case "java.lang.Double":
				Double 	y3=(Double)(x);
				Double	min3 =(Double)(y.pages.get(m).minValue);
				Double max3 =(Double)(y.pages.get(m).maxValue);
				Double maxLpage3=(Double)(y.pages.get(m-1).maxValue);
				if(m!=arr.size() - 1) {
				Double minNpage=(Double)(y.pages.get(m+1).minValue);
				if(y3>=min3 && y3<=minNpage) {done=true;}
				}
				if(y3<=min3 && y3>=maxLpage3) {done=true;}
				if(y3>=min3 && y3<=max3) {done=true;}
				if(y3>=max3 && m==arr.size() - 1) {done=true;}
					break;
				case "java.util.Date":
				Date 	y4=(Date)(x);
				Date min4 =((Date)y.pages.get(m).minValue);
				Date max4 =((Date) y.pages.get(m).maxValue);
				Date maxLpage4=((Date)(y.pages.get(m-1).maxValue));
				if(m!=arr.size() - 1) {
					Date minNpage=((Date)y.pages.get(m+1).minValue);
					if(y4.compareTo(min4)>=0 && y4.compareTo(minNpage)<=0) {done=true;}
					}
				if(y4.compareTo(min4)<=0 &&y4.compareTo(maxLpage4)>=0) {done=true;}
				if(y4.compareTo(min4)>=0&&y4.compareTo(max4)<=0) {done=true;}
				if(y4.compareTo(max4)>=0 && m==arr.size() - 1) {done=true;}
					break;
				
				}
            }
            
            if (done)
                return m;
 
            switch (
					(getType(y.name,y.key))
				) {
				case "java.lang.Integer":
				int y1=(int)(x);
				int max =(int)(y.pages.get(m).maxValue);
				if(y1>=max) { done=true;}
					break;
				case "java.lang.String":
				String y2=(String)x;
				String max2 =(String)(y.pages.get(m).maxValue);
				if(y2.compareTo(max2)>=0) {done=true;}
					break;
				case "java.lang.Double":
				Double 	y3=(Double)(x);
				Double max3 =(Double)(y.pages.get(m).maxValue);
				if(y3>=max3) {done=true;}
					break;
				case "java.util.Date":
				Date 	y4=(Date)(x);
				Date max4 =((Date) y.pages.get(m).maxValue);
				if(y4.compareTo(max4)>=0) {done=true;}
					break;
				}
            
            if (done)
                l = m + 1;
 
            else
                r = m - 1;
        }
 
        return -1;
    }
	

	public static int binarySearchUpdateAndDelete(Vector<Data> arr, Object x,  Tabel y) throws IOException{
		int l = 0, r = arr.size() - 1;
	       
        while (l <= r) {
        	 boolean done = false;
            int m = l + (r - l) / 2;
            if(arr.size()==1) {return 0;}
            else if(m==0) {
            	switch (
    					(getType(y.name,y.key))
    				) {
    				case "java.lang.Integer":
    				int y1=(int)(x);
    				int	min1 =(int)(y.pages.get(m).minValue);
    				int max1 =(int)(y.pages.get(m).maxValue);
    				if(y1>=min1 && y1 <= max1) {done=true;}    
    					break;
    				case "java.lang.String":
    				String y2=(String)x;
    				String min2 =(String)(y.pages.get(m).minValue);
    				String max2 =(String)(y.pages.get(m).maxValue);
    				if(y2.compareTo(min2)>=0&&y2.compareTo(max2)<=0) {done=true;}
    					break;
    				case "java.lang.Double":
    				Double 	y3=(Double)(x);
    				Double	min3 =(Double)(y.pages.get(m).minValue);
    				Double max3 =(Double)(y.pages.get(m).maxValue);
    				if(y3>=min3 && y3 <=max3) {done=true;}
    					break;
    				case "java.util.Date":
    				Date 	y4=(Date)(x);
    				Date min4 =((Date)y.pages.get(m).minValue);
    				Date max4 =((Date) y.pages.get(m).maxValue);
    				if(y4.compareTo(min4)>=0&&y4.compareTo(max4)<=0) {done=true;}
    					break;
    				
    				}
            }else {
            switch (
					(getType(y.name,y.key))
				) {
				case "java.lang.Integer":
				int y1=(int)(x);
				int	min1 =(int)(y.pages.get(m).minValue);
				int max1 =(int)(y.pages.get(m).maxValue);
				if(y1>=min1 && y1<= max1) {done=true;}  				
					break;
				case "java.lang.String":
				String y2=(String)x;
				String min2 =(String)(y.pages.get(m).minValue);
				String max2 =(String)(y.pages.get(m).maxValue);
				if(y2.compareTo(min2)>=0 &&y2.compareTo(max2)<=0) {done=true;}
					break;
				case "java.lang.Double":
				Double 	y3=(Double)(x);
				Double	min3 =(Double)(y.pages.get(m).minValue);
				Double max3 =(Double)(y.pages.get(m).maxValue);
				if(y3>=min3 && y3<=max3) {done=true;}
					break;
				case "java.util.Date":
				Date 	y4=(Date)(x);
				Date min4 =((Date)y.pages.get(m).minValue);
				Date max4 =((Date) y.pages.get(m).maxValue);
				Date maxLpage4=((Date)(y.pages.get(m-1).maxValue));
				if(y4.compareTo(min4)>=0&&y4.compareTo(max4)<=0) {done=true;}
					break;
				
				}
            }
            
            if (done)
                return m;
 
            switch (
					getType(y.name,y.key)
				) {
				case "java.lang.Integer":
				int y1=(int)(x);
				int max =(int)(y.pages.get(m).maxValue);
				if(y1>=max) { done=true;}
					break;
				case "java.lang.String":
				String y2=(String)x;
				String max2 =(String)(y.pages.get(m).maxValue);
				if(y2.compareTo(max2)>=0) {done=true;}
					break;
				case "java.lang.Double":
				Double 	y3=(Double)(x);
				Double max3 =(Double)(y.pages.get(m).maxValue);
				if(y3>=max3) {done=true;}
					break;
				case "java.util.Date":
				Date 	y4=(Date)(x);
				Date max4 =((Date) y.pages.get(m).maxValue);
				if(y4.compareTo(max4)>=0) {done=true;}
					break;
				}
            
            if (done)
                l = m + 1;
 
            else
                r = m - 1;
        }
 
        return -1;
	}
	
	public static Object Read(String path) throws IOException, ClassNotFoundException {
		FileInputStream fileIs = new FileInputStream (path);
		ObjectInputStream is = new ObjectInputStream(fileIs);
		Object x =is.readObject();
		is.close();
		fileIs.close();
		
		return x;
	}
	
	public static void Write(String path ,Object x) throws IOException, ClassNotFoundException{
		FileOutputStream filesOs = new FileOutputStream(path);
		ObjectOutputStream os = new ObjectOutputStream(filesOs);
		os.writeObject(x);
		os.close();
		filesOs.close(); 
	}
	
	public static boolean checkindex (String tableName , String col) throws IOException{
		 String row;
		 BufferedReader csvReader = new BufferedReader(new FileReader("src/main/resources/metadata.csv"));
		 while ((row = csvReader.readLine()) != null) {
		     String[] data = row.split(",");
		if(data[0].equals(tableName) && data[1].equals(col) ) {
			if(data[4]=="true") {
			csvReader.close();
			return  true;}
		}
		 }
		 csvReader.close();
		return false;
	}
	
	public static Vector FindIndex (Tabel tabel , Hashtable hash,Gridindex grid ,int count) throws IOException, ClassNotFoundException, ParseException{
		Vector insert =new Vector();
		Vector pageRange=new Vector();
		pageRange.setSize(4);
		insert.setSize(grid.indexcol.size());
		if(grid.indexcol.size()==count) {
			for(int i=0 ; i<grid.indexcol.size();i++) {
				
				for(int j=0;j<grid.indexColRange.get(i).size();j++) {
				switch (
						(getType(tabel.name,(String)grid.indexcol.get(i)))
					) {
					case "java.lang.Integer":
						if(j==9) {if((int)grid.indexColRange.get(i).get(j).max>=(int)hash.get(tabel.key) && (int)grid.indexColRange.get(i).get(j).min<=(int)hash.get(tabel.key))
							insert.setElementAt(j, i);}else {
						if((int)grid.indexColRange.get(i).get(j).max>(int)hash.get(tabel.key) && (int)grid.indexColRange.get(i).get(j).min<=(int)hash.get(tabel.key))
							insert.setElementAt(j, i);}
						break;
					case "java.lang.String":
						String a=(String)grid.indexColRange.get(i).get(j).max;
						String b=(String)grid.indexColRange.get(i).get(j).min;
						if(j==9) {if(a.compareTo((String)hash.get(tabel.key))>=0 && b.compareTo((String)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}else {
						if(a.compareTo((String)hash.get(tabel.key))>0 && b.compareTo((String)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}
						break;
					case "java.lang.Double":
						if(j==9) {if((Double)grid.indexColRange.get(i).get(j).max>=(Double)hash.get(tabel.key) && (Double)grid.indexColRange.get(i).get(j).min<=(Double)hash.get(tabel.key))
							insert.setElementAt(j, i);}else {
						if((Double)grid.indexColRange.get(i).get(j).max>(Double)hash.get(tabel.key) && (Double)grid.indexColRange.get(i).get(j).min<=(Double)hash.get(tabel.key))
							insert.setElementAt(j, i);}
						break;
					case "java.util.Date":
						Date aa=(Date)grid.indexColRange.get(i).get(j).max;
						Date bb=(Date)grid.indexColRange.get(i).get(j).min;
						if(j==9) {if(aa.compareTo((Date)hash.get(tabel.key))>=0 && bb.compareTo((Date)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}else {
							if(aa.compareTo((Date)hash.get(tabel.key))>0 && bb.compareTo((Date)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}
						break;
					}
			}
				}
			Vector	tmp=grid;
			for(int n=0;n<insert.size()-1;n++) {
				tmp=(Vector)tmp.get((int)insert.get(n));
			}
			if(tmp.get((int)insert.get(insert.size()-1))==null) {
				pageRange.setElementAt(insert,2);
				return pageRange;
			}
			else {
			Bucket bb=(Bucket)Read((String)tmp.get((int)insert.get(insert.size()-1)));
			Vector ss=new Vector();
			ss.add(bb);
			pageRange=getPagerange(tabel,ss,hash.get(tabel.key)+"");
			
			pageRange.setElementAt(insert, 2);
			return pageRange;

			}	
		}
		else {
			int size =grid.indexcol.size()-count;
			
//			for(int i=0 ; i<count;i++) {
//				if (!(hash.contains(grid.indexcol.get(i)))){
//					return null;
//				}
//			}
			for(int i=0 ; i<count;i++) {
				
				for(int j=0;j<grid.indexColRange.get(i).size();j++) {
				switch (
						(getType(tabel.name,(String)grid.indexcol.get(i)))
					) {
					case "java.lang.Integer":
						if(j==9) {if((int)grid.indexColRange.get(i).get(j).max>=(int)hash.get(tabel.key) && (int)grid.indexColRange.get(i).get(j).min<=(int)hash.get(tabel.key))
							insert.setElementAt(j, i);}else {
						if((int)grid.indexColRange.get(i).get(j).max>(int)hash.get(tabel.key) && (int)grid.indexColRange.get(i).get(j).min<=(int)hash.get(tabel.key))
							insert.setElementAt(j, i);}
						break;
					case "java.lang.String":
						String a=(String)grid.indexColRange.get(i).get(j).max;
						String b=(String)grid.indexColRange.get(i).get(j).min;
						if(j==9) {if(a.compareTo((String)hash.get(tabel.key))>=0 && b.compareTo((String)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}else {
						if(a.compareTo((String)hash.get(tabel.key))>0 && b.compareTo((String)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}
						break;
					case "java.lang.Double":
						if(j==9) {if((Double)grid.indexColRange.get(i).get(j).max>=(Double)hash.get(tabel.key) && (Double)grid.indexColRange.get(i).get(j).min<=(Double)hash.get(tabel.key))
							insert.setElementAt(j, i);}else {
						if((Double)grid.indexColRange.get(i).get(j).max>(Double)hash.get(tabel.key) && (Double)grid.indexColRange.get(i).get(j).min<=(Double)hash.get(tabel.key))
							insert.setElementAt(j, i);}
						break;
					case "java.util.Date":
						Date aa=(Date)grid.indexColRange.get(i).get(j).max;
						Date bb=(Date)grid.indexColRange.get(i).get(j).min;
						if(j==9) {if(aa.compareTo((Date)hash.get(tabel.key))>=0 && bb.compareTo((Date)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}else {
							if(aa.compareTo((Date)hash.get(tabel.key))>0 && bb.compareTo((Date)hash.get(tabel.key))<=0) {
							insert.setElementAt(j, i);
						}}
						break;
					}
			}
				}
			Vector	tmp=grid;
			for(int n=0;n<insert.size();n++) {
				tmp=(Vector)tmp.get((int)insert.get(n));
			}
			Vector bucket =new Vector();
			if(size==1) {bucket.addAll(tmp);}
			else {
			for(int n=0;n<10;n++) {
				Vector vv =new Vector();
				vv=tmp;
				for(int k=0;k<size-1;k++) {
				vv =(Vector)vv.get(n);
				}
				for(int k=0;k<vv.size();k++) {
					if(vv.get(k)!=null) {bucket.add(vv.get(k));}
				}
			//	bucket.addAll(vv);
			}}
			if(bucket.size()==0) {}
			Vector result= new Vector();
			result.setSize(4);
			result=getPagerange(tabel,bucket,hash.get(tabel.key)+"");
			return result;
			
		}
		
	}
	
	
	public static Vector getPagerange(Tabel tabel,Vector v ,String key) throws ClassNotFoundException, IOException, ParseException {
		Vector result =new Vector();
		result.setSize(4);
		String min =null;
		String max =null;
		for(int f =0;f<v.size();f++) {
		Bucket bucket =(Bucket)Read((String)v.get(f));
		
		if(bucket.containsKey(key)) {result.setElementAt((String)v.get(f), 3);}////////
		
		 min=bucket.floorKey(key);
		 max=bucket.higherKey(key);
		for(int i=0; i<bucket.Overflow.size();i++) {
			Bucket tmp =(Bucket)Read(bucket.Overflow.get(i));
			
			if(bucket.containsKey(key)) {result.setElementAt(bucket.Overflow.get(i), 3);}//////////
			
			switch (
					(getType(tabel.name,tabel.key))
				) {
				case "java.lang.Integer":
					if(true) {
						int x=Integer.parseInt(bucket.floorKey(key));
						int y=Integer.parseInt(bucket.higherKey(key));
						int x1=Integer.parseInt(tmp.floorKey(key));
						int y1=Integer.parseInt(tmp.higherKey(key));
					if(x>x1) {min=(String) tmp.get(tmp.floorKey(key)).get(1);}
					if(y<y1) {max=(String) tmp.get(tmp.higherKey(key)).get(1);}
					}
					break;
				case "java.lang.String":
					if(true) {
						String x=bucket.floorKey(key);
						String y=(bucket.higherKey(key));
						String x1=(tmp.floorKey(key));
						String y1=(tmp.higherKey(key));
					if(x.compareTo(x1)>0) {min=(String) tmp.get(tmp.floorKey(key)).get(1);}
					if(y.compareTo(y1)<0) {max=(String) tmp.get(tmp.higherKey(key)).get(1);}
					}
					break;
				case "java.lang.Double":
					if(true) {
						Double x=Double.parseDouble(bucket.floorKey(key));
						Double y=Double.parseDouble(bucket.higherKey(key));
						Double x1=Double.parseDouble(tmp.floorKey(key));
						Double y1=Double.parseDouble(tmp.higherKey(key));
					if(x>x1) {min=(String) tmp.get(tmp.floorKey(key)).get(1);}
					if(y<y1) {max=(String) tmp.get(tmp.higherKey(key)).get(1);}
					}
					break;
				case "java.util.Date":
					Date x=new SimpleDateFormat("yyyy-MM-dd").parse(bucket.floorKey(key));
					Date y=new SimpleDateFormat("yyyy-MM-dd").parse(bucket.higherKey(key));
					Date x1=new SimpleDateFormat("yyyy-MM-dd").parse(bucket.floorKey(key));
					Date y1=new SimpleDateFormat("yyyy-MM-dd").parse(bucket.higherKey(key));
					if(x.compareTo(x1)>0) {min=(String) tmp.get(tmp.floorKey(key)).get(1);}
					if(y.compareTo(y1)<0) {max=(String) tmp.get(tmp.higherKey(key)).get(1);}
					break;
				}
			
		}
		}
		result.setElementAt(min, 0);
		result.setElementAt(max, 1);
		return result;

	}
	
	public static int getPropValues(String property) {
		InputStream inputStream;
		Properties prop = new Properties();
		try {
			String propFilePath = "src/main/resources/DBApp.config";
			inputStream = new FileInputStream(propFilePath);
			prop.load(inputStream);
			inputStream.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
		return Integer.parseInt(prop.getProperty(property));

	}
	
	public static void checkCol(String tablename,String colname) throws IOException, DBAppException {
		boolean found = false; 
		String row;
		 BufferedReader csvReader = new BufferedReader(new FileReader("src/main/resources/metadata.csv"));
		 while ((row = csvReader.readLine()) != null) {
		     String[] data = row.split(",");
		if(data[0].equals(tablename) && data[1].equals(colname) ) {
			found =true;
			break;
		
		}
		 }
		 csvReader.close();
		 if(!found) {throw new DBAppException("col does not exist");}
	}
	
	
	public static void main (String [] args) throws DBAppException, IOException, ClassNotFoundException, ParseException  {

			////date range 
			////delete bucket 
		
		
		
//	    Vector c =new Vector();
//		String x="0.7";
//		double y=Double.parseDouble(x);
//		
//		String x1="5.0";
//		double y1=Double.parseDouble(x1);
//		
//		double range =(y1-y);
//		 range =range/10;
//		 double u=y;
//	
//		for(int k=0;k<10;k++) {
//			double min=u;
//			double max=u+range;
//			
//			c.add(min);
//			c.add(max);
//			
//			u+=range;
//		}
//		System.out.println(c.toString());
	//	boolean o = 1.55555555<1.55555999;
	//	System.out.println(o);
		
//	    Vector c =new Vector();
//
//		
//		String x="43-0000";
//		int y=x.charAt(0);
//		Double z=(double)y;
//		
//		String x1="99-9999";
//		int y1=x1.charAt(0);
//		Double z1=(double)y1;
//		
//		Double range =(z1-z);
//		range =range/10;
//		Double u= z;
//	
//		for(int k=0;k<10;k++) {
//			Double min=u;
//		    Double max=u+range;
//		    int IntValue = (int) Math.round(min);
//		    int IntValue1 = (int) Math.round(max);
////		    if(IntValue>90 &&IntValue<97) {IntValue=97;}
////		    if(IntValue1>90 &&IntValue1<97) {IntValue1=97;}
//		    
//		    String finalmin=(char)IntValue+""+x.substring(1);
//		    String finalmax=(char)IntValue1+""+x1.substring(1);
//		    
//		    if(k==9) {finalmax=x1;}
//		   
//			c.add(finalmin);
//			c.add(finalmax);
//			
//			u+=range;
//		}
////		System.out.println(c.toString());
//		 Vector c =new Vector();
//		c.setSize(5);
//		c.size();
//		 c.remove(3);
//		  System.out.println(c.size());
		
//		Vector y=new Vector();
//		Hashtable p=new Hashtable();
//		p.put(1, 1);
//		p.put(2, 2);
//		Hashtable pp=new Hashtable();
//		pp.put(3, 3);
//		pp.put(4, 4);
//		y.add(pp);
//		y.add(p);
//		
//		Vector c=new Vector();
//		Hashtable ppp=new Hashtable();
//		ppp.put(2, 3);
//		ppp.put(9, 4);
//		c.add(pp);
//		c.add(ppp);
//		c.addAll(y);
//		
//	//	c.retainAll(y);
//		System.out.println(y.toString());
	
		
		
		//TreeMap<Vector,String> t=new TreeMap();
	//	t.put(y, "ss");
//		Object cc =10.111;
//		Object yy =3.4;
//		System.out.println(cc.hashCode());
//		System.out.println(yy.hashCode());
//		System.out.println(cc.hashCode()>yy.hashCode());
		
//		Map<String, String> gfg
//        = new TreeMap<String, String>();
//
//    // enter name/url pair
//    gfg.put("GFG", "geeksforgeeks.org");
//    gfg.put("Practice", "practice.geeksforgeeks.org");
//    gfg.put("Code", "code.geeksforgeeks.org");
//    gfg.put("Quiz", "quiz.geeksforgeeks.org");
//		for(Map.Entry<String,String> entry : gfg.entrySet()) {
//			  String key = entry.getKey();
//			  String value = entry.getValue();
//
//			  System.out.println(key + " => " + value);
//			}
		
		  
	}

}
