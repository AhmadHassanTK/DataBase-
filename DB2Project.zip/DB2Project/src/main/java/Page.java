import java.io.Serializable;
import java.util.Vector;

public class Page extends Vector implements Serializable {

	public Page () {
		
	}

}
